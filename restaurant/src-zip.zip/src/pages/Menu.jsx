import { useEffect, useState } from "react";
import { apiGet } from "../api/api";

export default function Menu() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    apiGet("/show_item/").then(setItems);
  }, []);

  return (
    <div>
      <h1>Menu Items</h1>
      {items.menu?.map(dish => (
        <div key={dish.DishId}>
          <h3>{dish.DishName}</h3>
          <p>{dish.Ingredients}</p>
          <p>{dish.Price}</p>
          <img src={dish.Image} width="100" />
        </div>
      ))}
    </div>
  );
}
