import { useEffect, useState } from "react";
import { apiGet } from "../api/api";

export default function ManageUsers() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    apiGet("/show_users/").then(data => setUsers(data.users || []));
  }, []);

  return (
    <div>
      <h1>All Users</h1>
      <table border="1">
        <thead>
          <tr>
            <th>Userid</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>

        <tbody>
          {users.map(u => (
            <tr key={u.Userid}>
              <td>{u.Userid}</td>
              <td>{u.Username}</td>
              <td>{u.Email}</td>
              <td>{u.Role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
