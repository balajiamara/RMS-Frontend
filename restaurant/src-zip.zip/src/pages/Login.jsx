import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { apiPost } from "../api/api";

export default function Login() {
  const { loadUser } = useContext(AuthContext);

  async function handleLogin(e) {
    e.preventDefault();
    const data = new FormData(e.target);

    const res = await apiPost("/login_user/", data);

    if (res.error || res.msg) {
      alert("Invalid Login");
      return;
    }

    // login sets cookie automatically
    await loadUser();
    window.location.href = "/";
  }

  return (
    <div>
      <h1>Login</h1>
      <form onSubmit={handleLogin}>
        <label>User ID</label>
        <input name="Userid" required />

        <label>Password</label>
        <input name="Password" type="password" required />

        <button>Login</button>
      </form>
    </div>
  );
}
