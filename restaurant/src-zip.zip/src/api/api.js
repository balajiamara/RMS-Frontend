const BASE = "http://127.0.0.1:8000"; // change after deploying

export async function apiGet(endpoint) {
  return fetch(BASE + endpoint, {
    method: "GET",
    credentials: "include"
  }).then(res => res.json());
}

export async function apiPost(endpoint, data) {
  return fetch(BASE + endpoint, {
    method: "POST",
    credentials: "include",
    body: data instanceof FormData ? data : new URLSearchParams(data)
  }).then(res => res.json());
}

export async function apiPut(endpoint, data) {
  return fetch(BASE + endpoint, {
    method: "PUT",
    credentials: "include",
    body: data instanceof FormData ? data : new URLSearchParams(data)
  }).then(res => res.json());
}

export async function apiDelete(endpoint) {
  return fetch(BASE + endpoint, {
    method: "DELETE",
    credentials: "include"
  }).then(res => res.json());
}
